const taskInput = document.getElementById("taskInput");
const taskList = document.getElementById("taskList");
const toggleMode = document.getElementById("toggleMode");

// Load saved tasks and theme from localStorage
window.onload = () => {
  const savedTasks = JSON.parse(localStorage.getItem("tasks")) || [];
  savedTasks.forEach((task) => renderTask(task.text, task.completed));

  const savedTheme = localStorage.getItem("theme");
  if (savedTheme === "dark") {
    document.body.classList.add("dark");
    toggleMode.textContent = "☀️ Light Mode";
  }
};

function addTask() {
  const taskText = taskInput.value.trim();
  if (taskText === "") {
    alert("⚠️ Please enter a task!");
    return;
  }
  renderTask(taskText, false);
  saveTasks();
  taskInput.value = "";
}

function renderTask(text, completed) {
  const li = document.createElement("li");
  if (completed) li.classList.add("completed");

  const span = document.createElement("span");
  span.textContent = text;
  span.onclick = () => {
    li.classList.toggle("completed");
    saveTasks();
  };

  const btnGroup = document.createElement("div");
  btnGroup.className = "btn-group";

  // Edit button
  const editBtn = document.createElement("button");
  editBtn.textContent = "✏️";
  editBtn.className = "edit";
  editBtn.onclick = () => {
    const newText = prompt("Edit task:", span.textContent);
    if (newText !== null && newText.trim() !== "") {
      span.textContent = newText.trim();
      saveTasks();
    }
  };

  // Delete button
  const deleteBtn = document.createElement("button");
  deleteBtn.textContent = "🗑️";
  deleteBtn.className = "delete";
  deleteBtn.onclick = () => {
    li.remove();
    saveTasks();
  };

  btnGroup.appendChild(editBtn);
  btnGroup.appendChild(deleteBtn);

  li.appendChild(span);
  li.appendChild(btnGroup);
  taskList.appendChild(li);
}

function saveTasks() {
  const tasks = [];
  document.querySelectorAll("#taskList li").forEach((li) => {
    tasks.push({
      text: li.querySelector("span").textContent,
      completed: li.classList.contains("completed"),
    });
  });
  localStorage.setItem("tasks", JSON.stringify(tasks));
}

// Toggle Dark Mode
toggleMode.onclick = () => {
  document.body.classList.toggle("dark");
  if (document.body.classList.contains("dark")) {
    toggleMode.textContent = "☀️ Light Mode";
    localStorage.setItem("theme", "dark");
  } else {
    toggleMode.textContent = "🌙 Dark Mode";
    localStorage.setItem("theme", "light");
  }
};

// Liquid blob follow cursor
const blob = document.createElement("div");
blob.id = "blob";
document.body.appendChild(blob);

document.addEventListener("mousemove", (e) => {
  blob.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`;
});
